<?php

namespace Fuga\Component\Form\Widget;

class CurrencyWidget extends AbstractWidget {
	
}