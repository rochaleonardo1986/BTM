<?php

namespace Fuga\Component\Form\Widget;

class StringWidget implements AbstractWidget {
	
}
