<?php

namespace Fuga\Component\Form\Widget;

class NumberWidget extends AbstractWidget {
	
}