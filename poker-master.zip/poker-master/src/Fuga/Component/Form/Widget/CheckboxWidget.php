<?php

namespace Fuga\Component\Form\Widget;

class CheckboxWidget extends AbstractWidget 
{
	
}