<?php

namespace Fuga\Component\Cache;

class FileCache extends AbstractCache {
	
}