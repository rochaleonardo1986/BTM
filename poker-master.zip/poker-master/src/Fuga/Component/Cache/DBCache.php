<?php

namespace Fuga\Component\Cache;

class DBCache extends AbstractCache {
	
}