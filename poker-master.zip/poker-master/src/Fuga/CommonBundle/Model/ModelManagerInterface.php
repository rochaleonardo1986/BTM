<?php

namespace Fuga\CommonBundle\Model;

interface ModelManagerInterface {
	
	public function get($name);
//	public function create($params);
//	public function delete($id);
	
}

